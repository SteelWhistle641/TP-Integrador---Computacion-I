const printButton = document.getElementById('print-button');

const printpage = () => {
    const printFrame = document.createElement('iframe');
    printFrame.style.display = 'none';
    printFrame.src = 'a.html';

    document.body.appendChild(printFrame);

    printFrame.contentWindow.focus();
    printFrame.contentWindow.print();
};


printButton.addEventListener('click', () => {
    printpage();
});